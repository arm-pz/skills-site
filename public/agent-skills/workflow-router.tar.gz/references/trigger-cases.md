# Trigger cases for workflow-router

Written to tune-skill's case format (`references/test-cases.md` in arm-pz/tune-skill). Judged from
the `description` frontmatter only, as an agent choosing what to load would. Competing
descriptions read: `skill-launch`, `tune-and-polish`, `release-gate-chair`, `seo-polish`,
`keyword-resolver`, `recruiter-lens`, `applicant-kit`, `solo-income-blueprint`, `findable`.

**Run:** hand-run on 2026-10-23 against the descriptions only. No automated triggering loop was run.

| # | Message | Expected skill | Pass condition | Result |
| --- | --- | --- | --- | --- |
| 1 | "I've got all your skills installed. Where do I start if I want to sell a small product online?" | workflow-router | names Workflow 9 · launch-a-product and hands step 1 to solo-income-blueprint | PASS ("which skill to use, what to run first") |
| 2 | "How do these skills fit together?" | workflow-router | prints the workflow table, runs `route_check.py --all` | PASS ("how the skills fit together") |
| 3 | "Get my site ready to ship and ranking on Google." | workflow-router | Workflow 3 · launch-safely then Workflow 4 · grow-search-traffic, says which it set aside first | PASS (quoted almost verbatim) |
| 4 | "I want to go from job hunting to an offer, step by step." | workflow-router | Workflow 5 · land-a-job, step 1 recruiter-lens | PASS ("run a job search") |
| 5 | "What should I run before I deploy this?" | workflow-router → release-gate-chair | routes to Workflow 3 · launch-safely and hands the whole gate to the chair | PASS, though release-gate-chair also matches "should we deploy"; both lead to the same chair |
| 6 | "Review my resume." | recruiter-lens | routing does not load | PASS ("Not for a request one skill already owns") |
| 7 | "Is this safe to launch? Give me a go/no-go." | release-gate-chair | routing does not load | PASS: one skill owns the verdict |
| 8 | "Take my skill idea all the way to published." | workflow-router or skill-launch | either loads; routing offers skill-launch as Workflow 1 · build-a-skill's packaged chain | PASS with overlap: both descriptions claim it. Routing defers to skill-launch when the user wants one command |
| 9 | "My skill isn't triggering." | tune-skill | routing does not load | PASS (single-skill request) |
| 10 | "Rewrite the meta descriptions on these pages." | wordsmith or seo-polish | routing does not load | PASS (single-skill request) |

## Boundary pairs

| Message | Should trigger | Why |
| --- | --- | --- |
| "Which skills do I need to launch a skill, and in what order?" | workflow-router | asks for the route, not the run |
| "Launch this skill end to end now." | skill-launch | asks for the packaged run |
| "What do I run to get this site safe and ranked?" | workflow-router | spans Workflow 3 · launch-safely and Workflow 4 · grow-search-traffic |
| "Is this build safe to ship?" | release-gate-chair | one verdict, one owner |
