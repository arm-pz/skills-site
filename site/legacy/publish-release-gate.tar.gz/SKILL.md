---
name: publish-release-gate
description: >-
  Publishes a new or updated skill through three distribution channels: marketplace plugin,
  agent discovery protocol, and tarball delivery via Cloudflare Pages custom domain. Use when
  someone says "publish to marketplace", "make discoverable by agents", "deploy skill site",
  or after completing a skill update that needs public distribution. Not for single-channel
  updates (use tune-skill), not for creating new skills (use draft-skill), and not for
  verifying existing deployments (use upstream-check).
version: 0.1.0
---

# Publish release-gate

Three channels, one pipeline. The goal is deterministic publication so every install path
delivers the same artifact with matching integrity.

## Prerequisites

| Requirement | Where it lives | If absent |
|---|---|---|
| Source repo | `~/.qoder/skills/<skill-name>` or git clone | Ask. Cannot package air. |
| Marketplace repo | `caffeinity-skills` with `.claude-plugin/marketplace.json` | Clone or ask for path |
| Skills site repo | `skills-site` serving `skills.caffeinity.com` | Clone or ask for path |
| Cloudflare CLI access | `wrangler` installed + authenticated | Install or use dashboard |

## Channel 1: Marketplace plugin entry

Edit `caffeinity-skills/.claude-plugin/marketplace.json`:

```json
{
  "name": "<skill-name>",
  "source": {
    "source": "github",
    "repo": "arm-pz/<skill-name>"
  },
  "description": "<one-line contract matching SKILL.md description>"
}
```

Rules:
- Description must match the SKILL.md `description` field exactly — no marketing fluff
- Repo name should be `arm-pz/<skill-name>` unless using a fork pattern
- Insert alphabetically in the plugins array
- Update `caffeinity-skills/README.md` install instructions to include the new entry

## Channel 2: Agent discovery index

Build the tarball from source:

```bash
cd ~/.qoder/skills/<skill-name>
tar -czf <skill-name>.tar.gz SKILL.md tests.md references/ scripts/ assets/
sha256sum <skill-name>.tar.gz
```

Copy tarball to `skills-site/agent-skills/<skill-name>.tar.gz`.

Edit `skills-site/.well-known/agent-skills/index.json`:

```json
{
  "name": "<skill-name>",
  "description": "<same as marketplace>",
  "type": "archive",
  "url": "https://skills.caffeinity.com/agent-skills/<skill-name>.tar.gz",
  "digest": "sha256:<hash-from-above>"
}
```

Rules:
- Schema must be `https://schemas.agentskills.io/discovery/0.2.0/schema.json`
- URL must be absolute and match the deployed custom domain
- Digest must match the actual tarball hash — verify before committing
- Insert alphabetically in the skills array

## Channel 3: Deploy to Cloudflare Pages

From the skills-site repo:

```bash
cd skills-site
npm run build  # or whatever generates dist/
wrangler pages deploy dist --project-name=<your-project> --branch main
```

Or if using the Worker-based setup:

```bash
wrangler deploy
```

After deploy, verify the custom domain `skills.caffeinity.com` resolves and serves the new content. Check:
- `https://skills.caffeinity.com/.well-known/agent-skills/index.json` returns valid JSON
- `https://skills.caffeinity.com/agent-skills/<skill-name>.tar.gz` downloads successfully
- Hash matches what was published in step 2

## Verification checklist

Run all three checks before declaring success:

**Marketplace**: Open `caffeinity-skills/.claude-plugin/marketplace.json` and confirm the entry exists with correct repo and description.

**Agent discovery**: Fetch the index:
```bash
curl -s https://skills.caffeinity.com/.well-known/agent-skills/index.json | jq '.skills[] | select(.name=="<skill-name>")'
```
Confirm digest matches local tarball.

**Tarball integrity**: Download and extract:
```bash
curl -sL https://skills.caffeinity.com/agent-skills/<skill-name>.tar.gz -o /tmp/test.tar.gz
tar -tzf /tmp/test.tar.gz  # list contents
sha256sum /tmp/test.tar.gz  # must match published digest
```

**Source repo**: Confirm `https://github.com/arm-pz/<skill-name>` is accessible and contains the same SKILL.md.

## Commit and push

Commit changes in each repo separately:

```bash
# In caffeinity-skills
git add .claude-plugin/marketplace.json README.md
git commit -m "Add <skill-name> to marketplace"
git push

# In skills-site
git add .well-known/agent-skills/index.json agent-skills/<skill-name>.tar.gz
git commit -m "Publish <skill-name> via agent discovery"
git push
```

## Rollback procedure

If verification fails:

1. Revert the marketplace commit and push
2. Revert the skills-site commits and redeploy previous version
3. Remove tarball from `skills-site/agent-skills/`
4. Document the failure reason in a memory note

Never leave a broken digest published — it poisons agent installs until fixed.
