---
name: release-gate
description: >-
  Runs the three pre-launch passes in sequence and returns one release posture — HOLD or
  ready — with three separate verdicts and one merged finding register. Use when someone asks
  "is this safe to launch", "ready to ship", "should we deploy", "give me a go/no-go", or
  before any deploy of a site or client app. It runs web-preflight for external exposure,
  pre-ship-security-red-team for application behaviour against an isolated environment, and
  pre-ship-performance-audit for measured speed, then applies a deterministic HOLD rule over
  the combined findings. Verdicts are never merged or averaged; a pass in one lane never
  covers another. Not for a single-lane check (invoke that skill directly), not for
  penetration testing of production, and not for performing the deploy itself.
argument-hint: <production URL> [--app <isolated/local URL>] [--project <path>]
version: 0.2.0
---

# Release gate

Three lanes, three verdicts, one posture. The gate's only added value over running the three
skills by hand is that the arithmetic is deterministic, the coverage is stated, and a lane that
did not run cannot be mistaken for a lane that passed.

## Inputs

| Input | Needed for | If absent |
|---|---|---|
| Production URL | `web-preflight` | Ask. A gate with no target is a template. |
| Isolated or local app URL | `pre-ship-security-red-team` | Lane is recorded **untested**. Never run red-team against production. |
| Project path | performance audit source review | Perf lane runs measurement-only and says so |
| `--skip-security` / `--skip-perf` | de-scoping a lane | Only honoured with the user's recorded reason. The reason explains coverage; the lane still holds on R1/R5 |
| HEAD sha | freshness | A lane recorded at another sha describes different code and cannot be reused |

Multiple hosts are audited independently and keep separate evidence and verdicts, then any
redirect or canonical-host relationship is named.

## Lanes

Run in order. Do not start the next lane on the strength of the previous one's pass.

**1 — Exposure.** `web-preflight`. Bounded GET/HEAD only, so production is in scope. Emit its
host verdict using its own precedence `BLOCK > INCONCLUSIVE > PASS WITH FIXES > PASS`, and its
`PREFLIGHT-<nn>` findings.

**2 — Application behaviour.** `pre-ship-security-red-team`. Local or isolated environment only,
with synthetic test accounts. This lane's verdict is accepted **only on mechanical evidence**:

```
node "<red-team-skill-dir>/scripts/check_results.mjs" <run-dir>              # before dispatching fixes
node "<red-team-skill-dir>/scripts/check_results.mjs" <run-dir> --require-fixes   # after fixes
```

Both must exit 0. Exit 1 means a row is missing, a verdict has no evidence, a fix lacks its
negative control, or an unmasked secret sits in the run directory — that is a gate failure, not a
reporting inconvenience. Findings are `REDTEAM-S<nn>`.

**3 — Performance.** `pre-ship-performance-audit`. Four read-only subagent audits; findings are
`PERF-<nn>` with `fixed-verified` only when an after-median was measured under the same
conditions. P0→CRITICAL, P1→HIGH, P2→MEDIUM, P3→LOW.

## Posture rule

Evaluate against the union of all three lanes' findings. Report the codes that fired, not just the
result — a reader must be able to re-derive the posture from the rows.

**HOLD** if any of:

| Code | Fires when |
|---|---|
| R1 | any lane verdict is `BLOCK`, `INCONCLUSIVE`, `HOLD`, `fail` or `untested` |
| R2 | a CRITICAL or HIGH finding has remediation `open` or `fixed-unproven` |
| R3 | the app lane is recorded with no checker exit code, or a non-zero one |
| R4 | a finding whose `touches` is `data`, `money` or `role` has remediation `open` or `fixed-unproven` |
| R5 | a required lane has no row at all |
| R6 | a lane's `git_sha` is not the current HEAD sha (when a sha was supplied) |
| R7 | `accepted-risk` with no `accepted_by` |
| R8 | a CRITICAL or HIGH finding whose `touches` is `unknown` — the gate cannot tell whether it crosses a boundary |

**ready** otherwise — scoped to the lanes that ran, with every `accepted-risk` item listed inline
and attributed to a user choice made in this session. `accepted-risk` is never inferred from
silence, urgency, or a prior approval in another context.

**A recorded de-scope does not clear R1 or R5.** `--skip-security` with a good reason explains the
coverage line; it does not turn `untested` into a pass. This is deliberate: the common failure mode
is a hurried reader who sees `ready` and stops. Posture is two-valued by design; `ready` means
"ready for the coverage stated", and the coverage line is part of the verdict, not a footnote.

Unrecognised enum values in a lane row or finding row are a contract break: report them and stop
rather than defaulting to `ready`. The scripted checker encodes the same rule as exit codes — `0`
ready, `1` HOLD, `2` contract break.

**Known disagreements with the shipped scripts.** Cross-checked 2026-10-18: 20 machine-testable
cases from `tests.md` fed to `arm-pz/release-gate-chair`'s `check_gate.mjs` (20/20 of its own
fixtures pass, so the script is self-consistent) — 17 agree, 3 do not:

- a lane de-scoped by the user returns `ready`. `descoped_by` makes the checker `continue`, skipping
  R1, R3 and R6 for that lane; fixture 03 asserts this as intended;
- a lane verdict outside the enum (`mostly-pass`, `pass`, a typo) returns `ready`. Finding rows
  reject unknown enums, lane rows only check the field is non-empty;
- `not-applicable` is not a first-class verdict, so a legitimately inapplicable app lane holds on
  R3 instead of clearing with its profile named.

The rule above is the approved one; the scripts are unfixed, and all three forks share the same
`check_gate.mjs`. Where they disagree, report both answers and name the code the checker skipped —
never adopt the looser rule because the script is already written. Full write-up:
`docs/superpowers/specs/2026-10-18-release-gate-design.md`, "Divergence found".

## Output

```
RELEASE POSTURE: HOLD | ready   (rule: <which codes fired, e.g. R1, R4>)
Coverage: exposure=<verdict> app-tests=<verdict|UNTESTED: reason> perf=<verdict|UNTESTED: reason>
Lanes: <sha each lane ran at, and the checker exit code for the app lane>

| finding-id | lane | route | severity | remediation | touches | accepted_by | evidence |
| PREFLIGHT-04 | exposure | /.env | CRITICAL | open | none | - | HEAD 200, 412 bytes |
| REDTEAM-S02 | app-tests | /api/orders/:id | HIGH | fixed-verified | data | - | run-dir/…#S02 |
| PERF-01 | perf | /guides | HIGH | fixed-unproven | none | - | no after-median |

Gaps: <each untested or de-scoped lane, with who chose it>
Next: <the specific actions that would flip the posture>
```

`touches` is `data`, `money`, `role`, `none` or `unknown` — severity alone cannot tell "HIGH" apart
from "HIGH, and it reaches another user's data", which is what R4 needs. `accepted_by` is mandatory
for `accepted-risk`; attribution is what makes acceptance real.

Then write the same register to `docs/release/<YYYY-MM-DD>-<target>-gate.md` in the project and
commit it. Re-runs reuse existing `finding-id`s — an id that changed meaning is a contract break;
note it rather than quietly renumbering.

The machine-readable copy of the run is the ledger: `.release-gate/<run-id>/lanes.tsv` and
`findings.tsv` in the audited repo, gitignored before the first row is written, tab-separated with
a header, `-` for empty, no quoting — so a stray tab breaks the run loudly instead of shifting a
field silently. The register above is the human-facing rendering of those two files; when they
disagree, the ledger and the checker's exit code win.

## Does not

- Deploy anything. Deploying a `HOLD` is the user's call, made in the open, never by this skill.
- Merge scores, average severities, or produce one number for three different kinds of claim.
- Convert an unrun lane into a pass, or report a partial run as complete.
- Run red-team against production, or reproduce a secret in the register — path, material type
  and redacted evidence only.
- Widen any lane's scope. New checks belong to the lane's own skill; the gate cites it.

Read `caffeinity-stack` before reporting for Caffeinity work — it holds the deploy runbook this
gate precedes, and the rule that no fabricated metric or proof may appear in a report. Workflow
W3 in `caffeinity-routing` is the sequence this skill implements.

This skill is the front door; the scripted posture rule ships in three candidate repos —
`arm-pz/release-gate-chair` (the gate runs the lanes and transcribes each finding table into the
ledger), `arm-pz/release-gate-ledger` (each lane appends its own rows), and
`arm-pz/release-gate-validator` (runs nothing, ingests reports already on disk). Their
`scripts/check_gate.mjs`, `references/ledger.md` and `tests/` are byte-identical, so the codes in
the table above are the same in all three; only who writes the rows differs. The winner is not
chosen yet. When a fork is available, run its checker and copy its exit code into the app lane row
rather than re-deriving the posture by hand.
