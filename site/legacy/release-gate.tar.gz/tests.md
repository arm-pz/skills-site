# Release gate — posture tests

Judge the *posture*, not file contents. For each input set, the rule in `SKILL.md` must yield
exactly one answer with no further judgement. If two agents can disagree on a case, the rule is
ambiguous and needs tightening here and in the skill.

| # | Lanes | Findings | Expected posture | Why |
|---|---|---|---|---|
| 1 | exposure `PASS`, app `PASS`, perf `PASS WITH FIXES` | one MEDIUM `open` | **ready** | Nothing CRITICAL/HIGH is unresolved; a hardening recommendation is not a block |
| 2 | exposure `PASS`, app **untested**, no de-scope recorded | — | **HOLD** | A required lane that did not run is not a passed lane; the coverage line must say `UNTESTED` |
| 3 | same as 2, user recorded `--skip-security` with reason | — | **HOLD**, R1 | A recorded de-scope explains the coverage line; it does not turn `untested` into a pass |
| 4 | exposure `INCONCLUSIVE` (blanket CDN responses), app `PASS`, perf `PASS` | none | **HOLD** | `INCONCLUSIVE` never becomes a pass because the rest went well |
| 5 | exposure `PASS`, app `PASS`, perf `PASS` | `PREFLIGHT-02` HIGH `fixed-unproven` | **HOLD** | Unproven is open for gating purposes |
| 6 | same as 5 | `PREFLIGHT-02` HIGH `fixed-verified` | **ready** | Verification evidence exists |
| 7 | all three lanes run clean | `REDTEAM-S04` HIGH `accepted-risk`, chosen by the user in this session | **ready**, risk listed inline | Accepted risk is allowed only when attributed to an explicit user choice |
| 8 | app lane ran; both `check_results.mjs` calls not executed | rows look fine | **HOLD** | Mechanical evidence is required; prose verdicts are not accepted |
| 9 | app lane ran, checker exit 1 (a fix has no negative control) | — | **HOLD** | A gate failure, not a reporting inconvenience |
| 10 | exposure `PASS` on `example.com`, `BLOCK` on `www.example.com` | `PREFLIGHT-01` CRITICAL `open` | **HOLD**, per-host verdicts kept separate | Hosts are audited independently; the overall precedence puts `BLOCK` first |
| 11 | any lane | one finding reaches another user's data, `fixed-unproven` | **HOLD** | Data/money/role-boundary findings need `fixed-verified`, whatever the severity label says |
| 12 | deployment is urgent, all lanes `ready`, user says "just ship it" | — | posture unchanged | The gate reports; the human decides. Urgency is not a remediation state |
| 13 | app lane ran at an older commit; current HEAD differs | rows clean | **HOLD**, R6 | A lane recorded at another sha describes different code and cannot be reused |
| 14 | all lanes run | CRITICAL with `touches=unknown` | **HOLD**, R8 | The gate cannot tell whether it crosses a boundary, so the lazy answer costs a HOLD |
| 15 | all lanes run | HIGH `accepted-risk`, `accepted_by` empty | **HOLD**, R7 | Attribution is what makes acceptance real |
| 16 | all lanes run | HIGH `accepted-risk` boundary crossing, `accepted_by=user` | **ready**, risk listed inline | Case 7 and case 11 resolved in favour of attribution: an explicit recorded choice outranks the gate's default, and only that |
| 17 | all lanes run | MEDIUM `fixed-unproven` | **ready** | R2 is scoped to CRITICAL and HIGH; a checker that holds on this is too blunt to be used |
| 18 | perf lane verdict `not-measured`, other lanes clean | no perf findings | **ready** | Measurement-only is a stated limit, not a failure |
| 19 | any lane row has a verdict outside the enum (`mostly-pass`) | — | **contract break**, exit 2 | Never defaults to `ready`; an unrecognised value is a broken row, not a soft pass. **The shipped `check_gate.mjs` answers `ready` here** — it rejects unknown finding enums but only checks that a lane verdict is non-empty. Missing guard, not a different rule |
| 20 | a required lane has no row written at all (vs. a row saying `untested`) | — | **HOLD**, R5 | Missing evidence and recorded absence of evidence hold differently — R5 catches the row that was never written |
| 21 | app lane `not-applicable`, profile named in `notes` | none | **ready**, gap named | The only legitimate way a lane clears without running: a claim about the target, not about the schedule. **The shipped `check_gate.mjs` answers `HOLD` (R3) here** — `not-applicable` is not a first-class verdict, so the app lane still demands a checker exit code. This case states the repair, not the current behaviour |

Rule of thumb when a new case seems to let a lane off: if the reason is about the **target**
(`not-applicable`, profile named), the lane may clear; if it is about **this run** (no time, no
environment, user chose one lane), it holds and the gap line says who chose it.

Two invariants worth re-checking whenever this file grows: a lane's pass never transfers to
another lane, and no number is produced by combining the three verdicts.
